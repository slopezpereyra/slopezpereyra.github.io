---
title: Recuerdos de verano
categories: [Personal]
---

$\S$ Bajo las tenues y pequeñas luces que colgaban sobre el aire nocturno del
patio, su rostro dejaba traslucir los vestigios guaraníticos, africanos y
europeos que conjugaban en él una hermosura sin nombre. El piso de ladrillo era
cercado por estrechas franjas de tierra fértil, alfombrada de perladas
piedrecitas blancas, desde las cuales decenas de plantas tropicales conjuraban
una especie secreta de encanto similar al de sus ojos negros. En efecto, había
en aquellos ojos todo lo que en América creemos —o fingimos creer— haber
enterrado, otorgándole lo que alguien describió correctamente como una «mirada
de cinco siglos». Sentada en silencio, descalza y con un cigarrillo en la mano,
la salvaje hojarasca de un jazmín brasilero abierta a poca distancia de su
oscuro cabello, como infinitos dedos que sueñan dar sonido a un instrumento
delicioso y primitivo, ella también se preguntaba quiénes fueron los hombres, los
infinitos hombres, que la habían llevado allí. Ella no lo sospechaba, pero ella
era —como todas las cosas— apenas algo más que un eco. Y yo la contemplaba con
el silencio respetuoso de los que invaden un cementerio, disimulando mi distante
asombro, aunque todo en mí sintiera que una reverberancia de voces milenarias
iba aflorar, en cualquier momento, desde sus labios.

—¿Qué hace?—me pregunté, temiendo que lograra desnudar mi corazón, y una voz
interior me dijo «está esperando». Sus pies descalzos se unieron el uno al otro
como dos trenzas juveniles; sus dedos se entrelazaron y recorrieron su cuerpo
como enredaderas silvestres; el patio se deshizo y dio lugar a una hierba
milenaria, inundando mis sentidos cruel o tiernamente. Nada quedó a mi
alrededor. Solo y confundido, miré la hermosa flor que había nacido ante mí, que
ya no me increpaba con cinco siglos de mirada. Y repetí en silencio: «está
esperando».

--- 

$\S$ Cuando todavía era un niño enamoradizo, me entregué —como a tantas otras
cosas que la gente gustaba de llamar «pérdidas de tiempo»— a la lectura de
Matsuo Bashō y Kobayashi Issa. Parece mentira, pero aquella tarde había
recordado el dulce haiku que promete la incipiencia del amor:

>Under the cherry blossoms<br>
>strangers are not<br>
>really strangers.<br>

Aunque el calor era insoportable y el día era clarísimo, quienes conocíamos el
inclemente clima de esta región del mundo sabíamos que se avecinaba una tormenta
tropical. Estábamos reunidos en un antiguo patio donde la gente de la ciudad se
amontona a escuchar música bajo la amorosa sombra de los mangos y los urunday,
meciendo nuestros sentimientos al son de unas canciones con un dejo folklórico y
feliz, como se mece a un niño febril que quiere llevarse a las serenas regiones
del sueño. 

Lentamente los tintes carmesíes del arrebol fueron invadidos por una oscuridad
de plata. Los cuerpos, los cuerpos de las gentes y las cosas, aparecían ante mí
como fantasmas nativos de un mundo mágico y perfecto. Una profunda soledad
invadió mi corazón, tal vez porque la música se había vuelto melancólica, tal
vez porque en mis puños cerrados todavía me aferraba a un puñado de ceniza y la
sentía escaparse de mis manos lentamente, como el polvo fino de un reloj de
arena pasa de una parte a otra. «Así me escondo en este mundo»—pensé—«con esta arena, con este recuerdo apretado entre mis
manos». 

Salí a sentarme solo en un banco de madera, cerca de un árbol de naranjos, con
el alma oprimida por la añoranza de una mujer que ha muerto, del deseo de verla
bailar en la hojarasca con aquellas personas que no la conocieron, del ansia de
volver a sentir sus manos y su voz llamándome, pero esta vez sin lágrimas ni
pena. ¿Qué puede doler más que el pensamiento desesperado de querer hundir los
labios en la tierra para llamar un nombre que, día a día, es recordado por menos
y menos personas? Lentamente, como un yaguareté que acecha en los juncales, la
tormenta iba anunciándose en la voz del viento.

Sentí aproximarse, más que un cuerpo, una mirada—una que algunos días después,
en otro patio nocturno, llamaría una «mirada de cinco siglos»—. No sé cómo pero
supo recordarme que había otro mundo dentro, un mundo de personas vivas que
bailaban vivamente, besándose los labios o tocándose las manos, amándose en
secreto aunque fuera por sólo unos instantes, bajo el influjo de una música a la
vez citadina y de interior. Aquellos ojos negros eran ojos vivos y, en cierto
modo, me llamaron al mundo de los vivos. Y entonces abandoné mi pensamiento,
abandoné a mi amada muerta, y mirando a la muchacha que ya se levantaba de mi
lado pensé:

>Bajo el árbol de naranjos<br>
>los extraños no son<br>
>verdaderamente extraños

Poco después la tormenta desató su furia, como una bendición, sobre nosotros.

---

$\S$ Aunque lentamente, las nubes de la tormenta ya empezaban a disiparse en el
cielo gris que plateaba las aguas del Paraná. Durante los primeros minutos de
conversación, como es usual en estas ocasiones, mis palabras zozobraban un poco
y me sentía levemente vulnerable. Con toda certeza, ella sabía la verdad de mi
corazón, y lo tenía ante sí desnudo y sin tinieblas que escondieran sus
secretos. Sentí que la fuerza del río, como un lazo espiritual, nos unía
misteriosamente. Es posible que fuéramos peces en un acuario íntimo y secreto, o
juncos que arriman sus cabezas o enlazan sus raíces en el lecho del río, o las
dos torres de un frágil castillo de arena. Sus ojos me parecían otra vez estar
pletóricos de tiempo, llenos de siglos, eras y estaciones. Su rostro pérsico,
perfilado sobre las aguas argentadas del río, era alumbrado por la poca luz
pálida que rompía las densas nubes de la tormenta menguante. 

Hablamos de los dos milenios de Roma, de cierta anécdota divertida que recuerdo
de mi estadía en Cuba, de mis viajes a la India y sus viajes a Europa, de
*Twin Peaks*, de la trama de una novela de Conrad, y del minimalismo de
las letras en las canciones que había escrito en su álbum. Una pinta de cerveza
acompañó estas digresiones, y un observador incauto tal vez se apresuraría a
decir que mi incipiente estado de ebriedad era la explicación de mi adquirido
desenvolvimiento, de mi relajación, de que mis palabras no zozobraran más sino
expresaran, con el distendido auxilio de mis manos, la alegría que se gestaba en
mi interior. Pero esto sería equivocado. Toda mi paulatina calma era abrigada
por una sola causa: la creciente sospecha de que no estaba solo, de que ella
sentía, si no lo mismo que yo, algo parecido; sospecha que era apenas algo más
que una esperanza, pero que se encendía más y más gracias a al nosequé que ardía
en su mirada.

En este tipo de circunstancias, suele suceder que el mundo exterior parece
emular nuestro fuero interno. Tal vez por eso, a medida que la angustia que se
había formado en mí, pensándome perdido, se trastocaba en esperanza, las nubes
densas se disipaban más y más, llenando el horizonte de rayos carmesíes que
penetraban la superficie del río como dagas celestiales. Yo estaba de espaldas a
la puesta del sol, de manera que contemplaba el arrebol del horizonte
derramándose no en el agua, sino en la piel oscura de su exótico rostro.
Comprendí, al ver sus ojos teñidos de un púrpura exquisito, que el horizonte
gris a mis espaldas se había convertido ya en un mundo de celajes ardientes. El
arrebol intenso de mi tierra se diluía sobre aquellos ojos antiguos, como tinta
escarlata echada en el agua de un estanque japonés, causando en mí una
suerte de asombro primitivo. 

Muy pronto el agua se oscureció y la crueldad de la noche se alzó sobre nosotros
como un vengativo hechizo guaraní. Solo entonces comprendimos, con claridad
total, lo que ocurría. Después de besarla sentí en mis labios un sabor extraño y
desconocido. Era un sabor a tiempo, como el sabor que sentiría un hombre si
besara la cara oscura de la luna. Estuvimos quietos un momento, un instante en
que sólo el agua continuó su curso milenario. Parecíamos estatuas inmóviles en
esta región del mundo llena de huellas ocultas. Me pregunté si aquel beso
también dejaría una huella en las arenas, o una marca singular en el río, como
una moneda de plata que, arrojada en él, brilla secreta y milenariamente en su
profundidad. Pero no abrigué esperanza: era posible que mañana todo se
desvaneciera, que la moneda de plata se hundiera en el lecho fangoso, o fuera
tragada por el pez más viejo del río. 

Fuimos —ahora lo comprendo— lo que tantos otros han sido: fantasmas
aparecidos e idos en el curso de unas horas, de modo tal que nadie, ni siquiera
nosotros, ha de saber con certeza sin en verdad estuvimos allí, o si no seguimos
allí ahora mismo, como dos espectros, en el atardecer eterno de un sol que nunca
acaba de ponerse. La moneda de plata, recién arrojada al río, todavía se hunde y
no ha tocado el fondo lúgubre. Es imposible decir si brillará como una estrella
subfluvial, o sucumbirá en un fondo lleno de peces primitivos y recuerdos que,
siniestramente, yacen sepultados.

---

$\S$ Sobre la hierba prolija del cementerio, no sé si sus sandalias negras con
encajes brillantes ofendían o alegraban la solemnidad de los muertos. Su remera
negra tenía un precioso y seductor escote lágrima, dentro del cual un suave
lunar perlaba una piel bronceada durante aburridas siestas de tomar sol. Conversaba
con cierta impertinencia sobre el consumo de drogas, la vida después de la
muerte y la naturaleza del alma, sentada junto a la tumba de nuestra vieja amiga,
que se suicidó tras años de adicción y deterioro psicológico y moral. Acomodó
las flores y limpió la tierra y el agua de lluvia que se acumulaban sobre la
lápida con una delicadeza y un cariño que me parecieron maternales. El amor que
sintió alguna vez por la amiga muerta permanecía intacto, y aunque otros
visitantes pudieran juzgar sus ropas hermosas, su conversación desafortunada y
un tanto ruidosa, su actitud despreocupada—en fin, su aparente impertinencia
en aquel silencioso cementerio—la bondad de su corazón, la sinceridad de sus
dolores íntimos, y su espontánea calidez eran igual de aparentes.

Pocos meses antes, ella fue mi acompañante durante mi primera visita al
cementerio, una tarde lluviosa y melancólica en la que mi dolor todavía era
fresco y lacerante. Esta vez, para mi sorpresa, no sentí nada. Mi atención
estaba centrada en los vivos, en el hermoso rostro de mi acompañante, en su
extraña conversación, que yo escuchaba con cierta pasividad resignada. Ella
vivía una vida distinta a la mía, en un universo distinto al mío. La hermosura de
sus ropas, la delicadeza de su maquillaje, el bronceado de su piel, el brillo de
sus sandalias, su escote lágrima—en resumen, todos los detalles superficiales que
podrían sugerir un alma superficial—no revelaban ni vanidad vulgar ni, al fin
y al cabo, siquiera sana coquetería. En su consciencia, cada instante era
signado por la duda de sí misma, por la abrasante convicción de que una mujer
sólo es tomada en serio si satisface cierto criterio perverso de perfección, que
nadie—tampoco yo—podría amarla si lo más mínimo de su fuero externo sufriera
la más pequeña alteración. 

Desde su tierna infancia, padres y hermanos le enseñaron—sin mediar palabra
alguna—que la delgadez y la belleza garantizaban a las mujeres un trato
respetuoso y diferencial, humillándola por su intermitente gordura e inculcando
en ella la creencia, no del todo errada en muchos círculos, de que el amor
otorgado a una persona es proporcional a la gratificación estética que es capaz
de producir. Yo la comprendía y soñaba mostrarle que el amor puede ser perfecto,
pero nos presentía a la vez separados por un río inabarcable, y al verla abrazar 
tan firmemente las mismas convicciones que destruían su posibilidad de
ser feliz, la consideraba—en cierta medida—una partícipe del crimen. 
Comprendí que yo no debía «despertarla»: sus ojos estaban bien abiertos en un mundo, en una
vida, donde todas aquellas cadenas que a mí me parecían tan lejanas eran
verdaderas, tenían un peso espiritual que dificultaba real, incluso físicamente
sus pasos. Por eso la compadecía sin saber del todo cómo hablarle.

Unas horas después nos despedimos, solos en la oscuridad de la noche, mirándonos
frente a frente en la calle de tierra que conduce a la quinta de mi padre,
rodeados de luciérnagas cuya aparición intermitente reflejaba la inconstante
llama de la felicidad a lo largo de su vida. «Amo las luciérnagas», me dijo, sin
sospechar la triste ironía que inundó mi corazón. Besé sus labios y nos
abrazamos en silencio. Éramos irremediablemente diferentes—ella lo supo y yo
también—y sin embargo sabíamos comprender los duelos secretos del otro. Y eso
también es una forma del amor.

---

$\S$ ¿Por qué, al recordar un lugar, no damos preponderancia a los sueños
soñados en él? Decimos «allí vi este monumento», «allá vi este río», pero nunca
«allá soñé una luna carmesí» o «aquí mis sueños fueron plácidos». En los sueños,
rara vez sentimos que nos equivocamos, y posiblemente se deba a que no lo
hacemos. Sin embargo, priorizamos esta vida de desaciertos y errores.

Este verano soñé con dos hermosos ojos negros que, intermitentemente, iban de su
propia forma a otras formas más extrañas: primero eran dos ojos, luego dos gotas
de agua clara; eran ojos otra vez, y luego dos personas no del todo idénticas;
dos ojos, dos espadas oxidadas, y otras formas que he olvidado. Soñé que nos
invadía el Paraguay y yo, traidor a mi patria, luchaba en el bando paraguayo.
Soñé que estaba solo, «sin padre ni madre», en una playa fría. Soñé a mi antiguo
profesor de música sonriendo. Soñé que me enamoraba de una joven y, en efecto,
amanecí enamorado de ella. Soñé que moría y pensaba: «esto fue todo, la quise
tanto, que Dios la proteja». Soñé piezas de ajedrez que intentaban en vano
repetir una partida de Morphy. No soñé, lamentablemente, con Paulina, cuyo
rostro sólo puedo ver en sueños y extraño mucho últimamente.
