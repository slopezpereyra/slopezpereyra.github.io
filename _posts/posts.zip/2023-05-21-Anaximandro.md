---
title: Anaximander - Cosmogony and archetypes
categories: [ Philosophy ]
---

## Preliminary comment

The purpose of this entry is to serve as record of a particular period
in my intellectual life. It contains what originally were the scattered
notes of a rereading of the Presocratic philosophers. At the time, I was
simultaneously studying the ninth volume of the *Complete works* of C.G.
Jung. The coincidence of these separate studies conferred the notes with
a rather peculiar tone—so much, in fact, that their content appears to
me strange and almost pointless.

The notes are around three years old as of today, so I take little
responsibility for any claim they may contain. I am hardly who I was
yesterday—let alone that many years ago. They end quite abruptly, for
it seems I began to confuse myself, and although I perhaps expected to
resume them sometime, that never occurred. Truncated as they are,
strange in content, and virtually lacking any form of methodology, I
gather them here for the world to see. And this because the core
intuition that propelled me to write them, and to organize them into a
single text, is kindled still within me.

I speak of the suspicion that human experience, even across its wide
range of cultural and spatio-temporal differences, tends to structurally
identical patterns of representation. To put it differently, I mean the
idea that there exists a symbolic counterpart of instinct, that there
are innate tendencies of symbolic representation—perhaps the byproduct
of the emergence of symbolic faculties in instinctive animals. This is
what I loosely mean by *archetypical* images. Instinct and archetype are
here understood to be enantiomeric.

Archetypes, if they exist, are not eternal symbols floating in the soul
of man. They are, if anything, a biological tendency. Every human
faculty varies within a limited range—nothing distinctly human could
otherwise exist. I am currently putting in writing a survey of the
existing evidence in favour of this "collective unconscious". I shall
refer any discussion on this matter to that upcoming work and disregard
it for the time being. Suffice it to say, the whole of these notes may
boil down to an attempt at discerning, between certain mythological
expressions and Presocratic cosmogony, an isomorphism.

## Introduction

Presocratic thought, in spite of tremendous efforts, remains in almost
total obscurity. The Aristotelian exegesis, which sees in it nothing but
a rational attempt at describing the Φύσις, casts its shadow over
practically all philology. Granted, part of the Presocratic tradition
was a genuine effort for discerning the natural properties of the world.
But the fact that, in every philosopher, the most natural postulates
were derived, as a general rule, from some mythical ground which was the
corner stone of his doctrine, suggests that this part was also the most
superficial. Every ἀρχή is ultimately arbitrary and irrational, and none
of them can be explained as a strictly scientific *intellectio*. They
are cosmogonic images of speculative nature, whose resemblance with
mythological expressions make them worthy of the epithet of *mythical*.
In Anaximander's τὸ ἄπειρον and Anaxagoras' νοῦς, for example, this is
particularly clear. Philologists have tried to explain this mythical
aspects in three different ways.

$a.$ The first consisted in trying, sometimes with admirable
intelligence, to show that these mythical expressions were in truth
strictly rational—or simply assuming this was the case. Thus, for
example, Hesiod's χάος is the logical regression from complex to simpler
elements (Gigon, 1971), Anaximander puts the earth at the center of the
universe compelled by a geometric intuition (Jaeger, 1933), and
Aristotle teaches that Thales chose water as the ἀρχή by virtue of its
transmutability. But it is illicit to project a naturalist spirit to
postulates that, taken by themselves, are closer to myth than to
empirical observation. Presocratic philosophy, in this sense, is similar
to alchemy, which is sometimes described merely as a pre-scientific
study of matter, when undoubtedly it is also a complex symbolic universe
(Jung, 1944; Roob, 2014).

$b.$ In other cases, the mythical grounding of Presocratic philosophy
was recognized, but nothing was seen in it but an aristocratic
diversion, a manifestation of the drunken and Dionysian spirit of the
Greeks. That was the stance of Nietzsche and Colli, for example. This
hypothesis, however, has two problems. First, it misses the tremendous
resemblance between the symbolic expressions that appear in Presocratic
philosophers and those of many other myths. It is not the time to point
this resemblances out, but we shall deal with some of them in a moment.
They show that, in what comes to its irrational aspect, Presocratic
thought is not all that original, and that what is attributed to a
properly Greek amusement might turn out to be universal representations.
Secondly, the symbolic expressions that are thus explained have, in
truth, very little in common with with the typical worldview of ancient
Greeks. This will become clearer when describing point $c.$

$c.$ The third explanation consists in the appeal to some eastern
influence—be it Persian, Babylonian, or Egyptian. This hypothesis
deserves our attention the most, because it is the most plausible. It is
a fact that Presocratic Greece was in continuous contact with other
peoples, so much so that many Presocratic philosophers were colonial
agents or travelers themselves. But it is imperative to observe that,
for the Greek, nature was the total expression of the divine. The gods
were not agents of miracles, but the force that kept the wheel of
natural order turning. Religious feeling was engrained in objective
reality and not in the portentous. This is why Otto (1929) claimed that
the Greek worldview had, as a basic character, a "natural ideality or
ideal naturality", and Gigon (1971) made the clever observation that
the characters of the *Theogony* were not brought about because they
were gods, but because one cannot obviate the regions represented by
them in a wholesome picture of reality.

The eastern sentiment, quite contrarily, was that objective reality was
not the background of divine agency, but the illusory veil that
separates us from it. The divine delve on an immaterial realm that only
coincided with sensible reality by means of occult correspondences. The
immaterial soul, a matter of little importance to the Greek, had a
preponderant role. Thus, while the Greek conceived himself to be a
member of an objective reality where the divine was manifest, the
eastern man conceived reality to be the dream that distorts the divine
essence and from which he was to free himself. Where the Greek saw the
organic and the manifest, the eastern man guessed but a symbol and a
mystery. The first looked at the sun and saw the warm glow of Apollo,
who lived beyond the sea. The latter saw in it a light that existed only
because it had been created by his own sense of sight.

Granted, it is vain to describe the religious spirit of two peoples in
such a brief note. However, the synthesis above should suffice to show
that the Greek conception of reality was radically opposed to that of
eastern peoples, and that it provided to them a complete perspective of
the world, a sufficient framework of experience. Whence, then, would the
Greek spirit be so susceptible to eastern influence? For, indeed, if an
individual is, so to speak, touched by an idea, there must be something
in him susceptible to that touch, and the same can be said of a people.
If the phenomena that concerns us were reduced only to the peculiarities
of Greek culture, we should expect the latter to be quite impenetrable
to eastern religious sentiments—in a manner analogous to the way in
which we are deaf to a foreign language. The matter is even more
problematic when we consider, as we said before, that at the moment in
which Presocratic philosophy was flourishing, Greece, far from being
weakened or in crisis, found itself in an intense period of colonial
expansion and power (Lane Fox, 2007). It was besotted with pride and
without any need of incorporating foreign myths that were, on top of
everything, radically incompatible with those of its own. If eastern
peoples played a part, they did so incidentally, but not sufficiently
nor, ultimately, necessarily.

A hypothesis that may fill this voids and avoid this flaws must not
project over symbolic expressions a rational or empirical character, on
top of explaining its anti-idiosyncratic nature and resemblance with
other myths. My conjecture is that the different cosmogonies exposed by
Presocratic philosophers are archetypal images, whose expression in
other traditions has been pointed out, but whose influence in
Presocratic philosophy was overlooked by a hermeneutic tradition not
accustomed to such psychological concepts. I do not deny that the
discovery of the Φύσις was a genuine enterprise—I only claim it was
propitious to the projection of parallel psychological developments by
virtue of the mysterious and complicated nature of the cosmogonic and
astronomic phenomena in question, on one hand, and by the lack of a
scientific method that protected, so to speak, the inquiry from
psychological contamination.

In relation to the meaning of *archetype*, or archetypal image, I must
once more refer the reader to the entry *On archetypes*. For the
psychoanalytic conception, which I do not follow entirely, I refer him
also to both tomes of the ninth volume in Jung's *Complete works*. As a
quick summary, I should only say that by *archetype* I understand
phylogenetically determined, evolutionary archaic, and affective
patterns of representation. That we share a common affective substrate
with, at least, all mammals, is an established scientific fact
(Panksepp, 2000; Panksepp and Gordon, 2003; Panksepp, 2005; Panksepp,
2011). Furthermore, neuroscience has gathered some evidence in favor of
the existence of some of the specific archetypes theorized by Jung
(Alcara et. al., 2017). Of course, such evidence is inconclusive and
should be carefully interpreted.

Archetypes are not a metaphysical idea, a mystical intuition, nor an
abstraction. They are—so I believe—a psychological fact. The
advancement of neuroscience in the production of evidence must
necessarily be accompanied by the study of their concrete cultural and
behavioral manifestations. They are relevant for individual and social
life because the structures mediating primitive, affective behavior are,
as far as we can tell, also those modulating the construction of
meaning—as it is evidenced by the obstinate appearance of archetypal
images in myths and cosmogonies. They are, in all probability, the
product of "value-encoding neural systems"(Panksepp y Burgdof, 2003)
associated to the articulation of meaning.

I will focus on Anaximander for two reasons. Firstly, a study of this
sort over the whole corpus of Presocratic thought is a colosal endeavor,
far beyond my capacity and time.Secondly, Anaximander wrote one of the
most famous fragments of ancient philosophy; namely, the fragment D-K 12
A 10, whose cosmogonic character makes its comparative analysis somewhat
easier.

## Anaximander

The fragment of interest comes from Plutarch:

> «Anaximandro ... dice que lo infinito es la causa de la generación y
destrucción de todo, a partir de lo cual —dice— se segregan los
cielos y en general todos los mundos, que son infinitos. Declara que su
destrucción y, mucho antes, su nacimiento se producen por el movimiento
cíclico de su eternidad infinita... Dice también que, en la generación
de este cosmos, lo que de lo eterno es capaz de generar lo caliente y lo
frío fue segregado, y que, a raíz de ello, una esfera de llamas surgió
en torno al aire que circunda a la tierra, tal como una corteza
\[rodea\] al árbol; al romperse la \[esfera\] y quedar encerradas \[sus
llamas\] en algunos círculos, se originaron el sol, la luna y los
astros.»

Anaximander teaches that the origin of all things is "the infinite",
also translated as the Unlimited or the Undetermined. In this principle,
all pairs of opposites are contained, and so are all worlds, which are
released from it. The Unlimited produces the world in a continuous
fashion—it is not the creator at a sole and distant point in time, but
the perennial and continual agent of the generation and extinction of
things—it is *el fondo del movimiento cósmico*.

From the Unlimited, a "seed"(γóνιμον, "that which is $\ldots$
capable of generation") of light and night was segregated. The word
γóνιμον is an important subtlety. From the Unlimited did not sprout
light and darkness, but that which engenders them. Light and night thus
constitute the original opposition, begotten by the seed that segregated
from the Unlimited. From a psychological perspective, one is tempted to
say this is a projection of the immemorial separation of consciousness
from primordial unconscious existence, similarly to the words of God:
"*let there be light*". It is said that light and night covered the
Earth like the cortex would a tree and in a double layer. Light was the
interior layer—night was the exterior one. But the husk of light was
teared appart—we are not told how nor why—and the fire that once was
total was dispersed in small spherical shapes. Those are the stars and
*astrums* we observe.

The world to which the seed is thrown, the cosmic state in which this
primordial segregation occurs, is the empty space, the mythical χάος
that is first proposed in Hesiod's *Theogony*. The word χάος does not
express, as Ovidio thought, an aleatory mess. It means something along
the line of *cavity* or *cleft*. It was used, for example, to denote the
wide opening of a mouth or the aperture of a cave. Its formulation as
primordial state is a widespread and well documented archetypal motif.
*Gensis 1:2* speaks of the abyss that was shadow only: "*And the earth
was without form, and void; and darkness was upon the face of the
deep*". The primordial Hunger in the *Vedas*, insofar as hunger is a
state of inner emptiness, or the universal symbol of the cave as a
transformation place—this is, of generation by means of prior
destruction—are also related to Hesiodic χάος. It is worth mentioning,
although briefly, the role of Mercury in alchemy, which Paracelsus said
to be "*the concealer of the rest \[of things\]—their corporeal
vessel* ($\ldots$)—"(Paracelsus & Ed, 2018). But what concerns us
now is that, in Anaximander, it is the seed of light and shadow what
alters that primordial state. That seed only is what induces content and
shape in the original void, covering the world with the double layer of
its fruit.

It must be said that, from a psychological perspective, the emergence of
consciousness is both an individual and a collective phenomena—it is a
phylogenetic and an ontogenenetic development. It is clear that
unconscious life precedes consciousness, and that the latter emerges
from the first in a continuous fashion—this is, by changes of *degree*
and not of nature. But awareness of thought came much later than thought
itself, and the emergence of consciousness is matricidal, insofar as the
flourishing of understanding comes with the relegation of an entire form
of life to a realm of absolute obscurity. Thus, in Anaximander, from the
Undetermined sprouts the initial contradiction of day and night,
conscious and unconscious life. This emergence, though expressing form-
and content-aquisition by means of resolving the original χάος and,
quite literally, producing a world—this is, though being a creative
act—also creates a tension inherent to the separation of a unity into
irreconcilable opposites. This tension seems to be what the tearing of
the light sheet expresses, which the philosopher never explains and is,
to my eyes, the result of an irrational intuition. Thus, the primordial
unity of light is also destroyed—and this immediately after being
conformed.

This dissemination of the original light into smaller spheres can be, on
its turn, associated to a different psychological fact. The *self*
archetype, expressed in the divine source of the Unlimited, is not only
an archetype but, insofar as it expresses a totality, union and source
of all the rest. Indeed, what psychoanalysis has termed *individuation*
can be thought of symbolically as the union of dispersed lights into a
single great luminary. These are two opposite forms of totality: the
primordial unconscious where everything is, so to speak, undivided—the
final integration of opposite poles. The first is the primordial origin,
the latter the ultimate end. In this sense, they imply each other as
logical necessities. This might be one of the most peculiar aspects of
the *self* archetype, if it truly exists—that is, that it expresses a
return to a pristine state of harmony and, at the same time, a positive
and forward-looking synthesis.

The image of the dispersed luminosities finds another parallel in the
*scintillae* of medieval alchemy. These are subtle flashes of light
present in the "substance of transformation", associated to the *anima
mundi* and the Holy Spirit. These two notions are different modulations
of a unique intuition; namely, that of the hidden and numinous force
that drives the world. It is no mystery then that the concept of
*scintillae* was associated to them, insofar as it conduces—and in
some sense spiritualizes—the process of alchemical transformation.
Kunrath calls these luminosities "*mundi futuri seminarium*". They are
"semillas de luz diseminadas en el caos".

The *self* archetype is abundant in modulations of various nature.
Insofar as it points to the totality of the psyche, it is, in general,
the intuition expressed by every form of monism or monotheism. Diogenes
of Apollonia, for example, postulated either the Undetermined or the
*air* as principle, according to different sources. The philologic
discussion interests us not, for if he spoke of air he did so not as a
material principle—this can only be an Aristotelian mistake—but as
engendering breath, as that air of life that was insufflated into every
thing existent. It is, then, quite identical to Anaximander's principle,
at least from a psychological perspective. Simplicius of Cicilia quotes
Diogenes in a passage of his *Physics* (151, 20-153, 5):

> «Me parece (\...) que todas las cosas que existen son alteraciones de
lo mismo, y que son lo mismo. (\...) Pero todas estas cosas se generan a
partir de lo mismo, como alteraciones diversas en diversos momentos, y
vuelven hacia lo mismo».

But we can even abandon the Greek world, where the philologists contents
himself with tracing a more or less clear chain of influences. In the
*Bṛhádāraṇyaka Upaniṣad*, the primordial Death, which is Hunger, creates
a mind. The new-born mind conceives the following thought: "*que yo
tenga un* ātman". The *ātman* is a clear modulation of the self
archetype, insofar as it points to the psychological self in its
absolute totality, the "transcendent"and "non-transcendent"planes
integrated. It is the breath that vivifies all things. As such it
relates to the *scintillae* of medieval alchemy and Diogenes' air. The
first wish formulated by this primordial mind is, then, a total and
unified identity. We are then told of the emergence of the first man,
the *Puruṣa*: "En el principio sólo era el ātman. Y no habiendo otro
salvo él mismo, pensó y se dijo: 'Soy yo'. De ahí que su nombre sea
'yo'".

This "yo", this "I", refers---using terms of psychoanalysis---not to the
self but to the ego, the subject of consciousness. Thus, with this thought, from
the primordial *ātman* the *Puruṣa* is formed. We find once again that the
formation of consciousness, expressed in the creation of the first man, implies
a lost of unity in the psyche, which is teared into *ātman*=self y *aham*=ego.
This intuition is the one projected by Anaximander when he speaks of the
production of light and night from the γóνιμον. This disruptive and
disintegrating character is what is expressed in the tearing of the light cortex
into smaller and disseminated spheres.

Of the *Puruṣa* we are also told that it has "a thousand eyes".
Ignacio de Loyola speaks of a vision that frequently became to him: a
glow that sometimes took the shape of a snake, and seemed filled of
shining eyes. Monoimo the Arab teaches that the primitive man possessed
"many faces and many eyes". Caesarius of Heisterbach says of the
*Anthropos*, the first man, that it was like a sphere and had eyes
everywhere (*ex omni parte oculata*). Angela of Foligno, in one
occasion, saw in the host "dos ojos esplendidísimos tan grandes que
parecía que de la hostia solamente quedaban los bordes". She also
recalls: "($\ldots$) una vez no ante la hostia, sino en la celda, se
me aparecieron ojos con tan gran belleza y tan deleitables que
ciertamente no creo que pierda nunca la alegría".

The association between the emergence of consciousness and phenomena
involving multiple lights is not, as we see, unusual. Its vinculation
with the *self* seems clear insofar as it occurs in experiences of
connection with the divine (be it in the Christian host or the Vedic
*ātman*). It is worth mentioning here that, once more, we observe the
double character of the archetype—its tone of primordial phenomenon
and of ultimate truth. As a last comment, these small luminosities,
expressed in polyoftalmic or astronomical visions, probably refer the
fragmentary phenomena of consciousness, while the greater light (the
divine eye or the sun as the eye of God, the *scintilla una* Kunrath
spoke of, etc.) is a modulation of the *self*. That these luminosities
have in general a spherical shape corresponds to the unifying and
integrating sense of the archetype, and we find this in Anaximander too,
since from the huks of light, small fires are dispersed "in some
circles". Hippolytus of Athens also tells that, according to
Anaximander, "the *astrums* we see are generated as a circle of fire,
separating from the fire of the world, each surrounded by air".

What I mean to record here, then, after so many examples, is that
Anaximander's doctrine is not at all original. It fits perfectly with a
mythological motif of extensive documentation. Even in the idea that the
principle governs all things, which appears in Diogenes also, the
parallel with the eye motif is evident, insofar as the capacity to see
it all is the hyperbolic form of government. So, God has eyes that
"están sobre el camino del hombre"and "is always watching everything
we do"(*Job, 34:21*), and Chronos is "the one that sees it all"to
Sophocles and "the devil that everything sees"in certain Greek
funerary inscription. Argos Panoptes, the thousand-eyed giant, is a
guardian and protector.

The archetype, naturally, is not confined to ancient mysticism. Emerson,
for example, spoke of a mysterious sphere that is and is not always the
same.

> Genius studies the causal thought, and, far back in the womb of
things, sees the rays parting from one orb, that diverge ere they fall
by infinite diameters. Genius watches the monad through all his masks as
he performs the metempsychosis of nature. Genius detects through the
flies, through the caterpillar, through the egg, the constant individual
(\...).

The primordial sphere, the thought that is the cause of all that is
existent, is the *principia*—it is the Pythagoric monad in relation to
which every death is but a transmigration—it is the hidden Individual
in the phenomenic world. To be and not to be always the same is a
synthesis of opposites, a common trait of the archetype, insofar as the
*self* is not a principle of perfection, but of completeness. The
totality of the psyche is precisely that: a totality. Therein lay all
shadow and all light, the chthonic and celestial worlds. That
Anaximander considers the opposites as contained in the Undetermined is,
therefore, consistent with the general phenomenology of the archetype.
The symbol of Christ, to name a familiar one, has a distinct
enantiodromic nature. The coming of the Antichrist is not a mere
prophetic dream, but the product of a psychological law that took
Christian mysticism to the idea of a coming reign of the shadows. This
is particularly manifest in Gnostic thought, among which we may point
out a particular passage from the *Pistis Sophia*. When Jesus was a
child, a spirit that proclaimed himself to be his brother, descended
onto Mary. It looked just like Jesus, and with Jesus she confounded him
—though he was from the inferior regions of Chaos. When reminding
Jesus of this episode, Mary tells of the spirit: "*he embraced thee
and kissed thee, and thou also didst kiss him, and you became one*".

Similarly, Angela of Foligno says that, when she heard the Holy Spirit,
she wanted to see if she could forget this voice that spoke into her,
and tells: "I started looking at the vines, so as to forget those words
($\ldots$), and wherever I would turn I would tell myself: 'This is my
creature'. And I felt an ineffable divine joy".

The mystical experience was so strong that she felt the whole of
creation belonged to her as it originally belonged to God. But
immediately after she says: "And then to my memory came all my sins and
my vices, and I saw in me nothing but sins and flaws".

To Angela of Foligno, the simultaneity of the sweet mystical experience
and the assault of her vices and sins against her memory was shocking. We
have mentioned the Gnostic intuition of the inseparability of Christ and
Antichrist, but here we find ourselves with a spontaneous experience of
this intuition in a catholic christian, who probably never thought the
voice of the Holy Spirit could come accompanied by such horrendous
darkness. But if we understood anything about the *self* archetype, such
simultaneity cannot surprise us. The experience was hardly interpretable
from the framework of catholic dogma, but from a psychological
perspective it is impeccably consistent. In general, and in accordance
to what we have thus far exposed, the archetype manifests as affected by
"equal yet opposite forces".

The exposition of so many examples is not an act of vain erudition. With
some luck, I have produced a decent record of the similarities between
Anaximander's doctrine and countless other myths. I have nothing else to
say, insofar as the whole matter is still obscure to me, and the more I
advance with these notes the more I mistrust my own conclusions. I
should prefer to close my notes on Anaximander here and resume them in
another period of my life, when some of these ideas have matured in my mind. I
am contempt with having put in writing all that which was coming to my mind as I
restudied Presocratic philosophy.
